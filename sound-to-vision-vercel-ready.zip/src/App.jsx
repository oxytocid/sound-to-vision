import React from "react";
import { Instagram, Mail, Phone, Globe, ArrowRight } from "lucide-react";

export default function App() {
  return (
    <div className="site">
      <section className="hero">
        <div className="heroGlow" />
        <p className="eyebrow">Creative Direction · Music Campaigns · Visual Concepts</p>
        <h1>SOUND <span>TO</span> VISION</h1>
        <p className="lead">Turning sound into visual concepts.<br />Creative strategy, viral formats and visual storytelling for artists.</p>
        <div className="buttons">
          <a href="#projects" className="primary">Explore Projects <ArrowRight size={17}/></a>
          <a href="#contact" className="secondary">Collaborate</a>
        </div>
      </section>

      <section className="section two">
        <div>
          <p className="eyebrow">About</p>
          <h2>Building artist worlds beyond music.</h2>
          <p>Sound To Vision develops visual identities, campaign ideas and social concepts that turn songs into experiences people interact with.</p>
          <p>From viral hooks and creator outreach to cinematic aesthetics and community-driven storytelling — the goal is to create emotional and culturally recognizable moments.</p>
        </div>
        <div className="card">
          <div><h3>Creative Direction</h3><p>Mood, identity, visuals, atmosphere and campaign concepts.</p></div>
          <div><h3>Social Campaigns</h3><p>TikTok/Reels strategies, repeatable formats and creator outreach.</p></div>
          <div><h3>Visual Storytelling</h3><p>Memorable artist aesthetics with cinematic and emotional visuals.</p></div>
        </div>
      </section>

      <section className="section dark" id="projects">
        <div className="inner">
          <p className="eyebrow">Current Campaign</p>
          <div className="two">
            <div className="campaign"><div><p>Release Campaign</p><h2>ALLO</h2><span>Christ Paka</span></div></div>
            <div>
              <h2>From hook to cultural moment.</h2>
              <p>The campaign is built around real reactions, relatable situations, creator collaborations and community-driven content.</p>
              <p>Instead of focusing only on a music video, the concept expands into short-form storytelling, reaction formats and social interaction.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="sectionHeader">
          <div><p className="eyebrow">Content Direction</p><h2>Visual Atmosphere</h2></div>
          <p>Mood-focused visuals inspired by nightlife, emotional storytelling, street culture and cinematic minimalism.</p>
        </div>
        <div className="grid">
          {["Street Energy","Behind The Scenes","Creator Campaigns","Visual Identity","Performance Moments","Music & Atmosphere"].map((item) => (
            <div className="tile" key={item}><span>Sound To Vision</span><h3>{item}</h3></div>
          ))}
        </div>
      </section>

      <section className="contact" id="contact">
        <p className="eyebrow">Contact</p>
        <h2>Let’s build something people remember.</h2>
        <p>Open for artist collaborations, visual concepts, creator campaigns and creative partnerships.</p>
        <div className="contactlinks">
          <a href="mailto:hello@sound2vision.com"><Mail size={18}/> hello@sound2vision.com</a>
          <a href="tel:+491777447291"><Phone size={18}/> 0177 7447291</a>
          <a href="https://www.instagram.com/sound2vision.berlin" target="_blank" rel="noreferrer"><Instagram size={18}/> @sound2vision.berlin</a>
          <a href="https://sound2vision.com"><Globe size={18}/> sound2vision.com</a>
        </div>
      </section>
    </div>
  );
}
