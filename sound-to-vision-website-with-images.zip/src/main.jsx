import React from "react";
import { createRoot } from "react-dom/client";
import { Instagram, Mail, Phone, ArrowRight } from "lucide-react";
import "./style.css";

const img = {
  bts:"/asset-01.jpg", overview:"/asset-02.jpg", stageOne:"/asset-03.jpg", crowd:"/asset-04.jpg", stageTwo:"/asset-05.jpg",
  contactSlide:"/asset-06.jpg", texture:"/asset-07.jpg", portraitCard:"/asset-08.jpg", start:"/asset-09.jpg", brand:"/asset-10.jpg"
};

function App(){
  return <main>
    <section className="hero">
      <img src={img.bts} className="heroImage" />
      <div className="shade" />
      <div className="heroContent">
        <p className="eyebrow">Creative Direction · Visual Concepts · Campaigns</p>
        <h1>SOUND <span>TO</span> VISION</h1>
        <p className="lead">Turning sound into visual concepts.</p>
        <div className="buttons"><a href="#work">Explore Work <ArrowRight size={17}/></a><a className="outline" href="#contact">Collaborate</a></div>
      </div>
    </section>

    <section className="intro">
      <div><p className="eyebrow gold">About</p><h2>We build artist worlds beyond music.</h2></div>
      <p>Sound To Vision develops visual concepts, rollout ideas and social-first campaign formats for artists — combining music, storytelling and cultural moments people can interact with.</p>
    </section>

    <section className="split" id="work">
      <div><p className="eyebrow gold">Current Campaign</p><h2>ALLO by Christ Paka</h2><p>A repeatable short-form format built around attention, reaction and a recognizable hairflip moment. Designed for street content, creators, cafés, barbershops and cinematic hero reels.</p></div>
      <div className="imageStack"><img src={img.stageTwo}/><img src={img.crowd}/></div>
    </section>

    <section className="gallery">
      <div className="sectionHead"><p className="eyebrow gold">Visual World</p><h2>Music. Culture. Story.</h2></div>
      <div className="grid">{[img.stageOne,img.crowd,img.stageTwo,img.overview,img.contactSlide,img.portraitCard].map((src,i)=><img key={i} src={src}/>)}</div>
    </section>

    <section className="process">
      <img src={img.start}/>
      <div><p className="eyebrow gold">Process</p><h2>Story is the structure. Vision is the outcome.</h2>
      <div className="processList"><div><b>01</b><span>Campaign Concept</span></div><div><b>02</b><span>Visual Identity</span></div><div><b>03</b><span>Creator Formats</span></div><div><b>04</b><span>Rollout Strategy</span></div></div></div>
    </section>

    <section className="services">{["Creative Direction","Music Campaigns","Visual Storytelling","Creator Outreach","Presskit & Pitch","Sponsor Integration"].map(x=><div className="service" key={x}>{x}</div>)}</section>

    <section className="contact" id="contact">
      <img src={img.brand} className="brandCard"/>
      <p className="eyebrow gold">Contact</p><h2>Let’s build something people remember.</h2>
      <div className="links"><a href="mailto:hello@sound2vision.com"><Mail size={18}/> hello@sound2vision.com</a><a href="tel:+491777447291"><Phone size={18}/> 0177 7447291</a><a href="https://www.instagram.com/sound2vision.berlin" target="_blank"><Instagram size={18}/> @sound2vision.berlin</a></div>
    </section>
  </main>
}
createRoot(document.getElementById("root")).render(<App/>);
